package com.example.testnews.presentation

interface PresenterInterface {
    fun getTopNews()
    fun onDestroy()
}