package com.example.testnews

class Const {
    companion object {
        const val API_KEY = "2bf7091839474fabab7744e15e2fbeeb"
        const val BASE_URL_NEWS = "https://newsapi.org/v2/"
        const val COUNTRY = "ru"
    }
}