package com.example.testnews.presentation

import com.example.testnews.model.NewsSource

interface ViewInterface {
    fun showLoading()
    fun showTopNews(news: NewsSource)
}